# Portafolio · Gustavo Harnisch

Sitio estático para GitHub Pages. Diseño moderno oscuro tech, listo para mostrar tu perfil y proyectos.

## Archivos

- `index.html` — estructura de la página
- `styles.css` — estilos (dark theme con acentos cyan/violeta)
- `script.js` — carga proyectos desde `projects.json`
- `projects.json` — lista de proyectos (¡edita este archivo para añadir/quitar!)

## Cómo publicar en GitHub Pages

1. Sube estos 4 archivos al repo `Gustavo-Harnisch.github.io` (en la rama `main`, en la raíz).
2. En tu repo: **Settings → Pages → Source: Deploy from a branch → main / root → Save**.
3. Espera 1–2 minutos. Tu sitio estará en `https://gustavo-harnisch.github.io/`.

## Cómo añadir un proyecto

Edita `projects.json` y agrega un objeto al array `projects`:

```json
{
  "name": "Mi proyecto",
  "description": "Qué hace y por qué mola.",
  "language": "Python",
  "url": "https://github.com/Gustavo-Harnisch/mi-proyecto",
  "featured": true,
  "tags": ["AI", "Backend"]
}
```

Marca `featured: true` para destacarlo con un borde y estrella ⭐.

## Personalizar

- **Email**: en `index.html` busca `mailto:hello@example.com` y reemplaza.
- **LinkedIn**: en `index.html` reemplaza el `href="https://linkedin.com"`.
- **Colores**: en `styles.css` ajusta las variables `--accent` y `--accent-2` al inicio.
- **Bio**: en `index.html` busca la sección `#about` y edita el texto.
