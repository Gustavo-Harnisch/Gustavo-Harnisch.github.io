// Carga proyectos desde projects.json y los renderiza en la grilla.
// Para agregar/editar proyectos: edita projects.json y haz push al repo.

(async function () {
  document.getElementById('year').textContent = new Date().getFullYear();

  const grid = document.getElementById('projects-grid');
  const stat = document.getElementById('stat-projects');

  try {
    const res = await fetch('projects.json', { cache: 'no-cache' });
    if (!res.ok) throw new Error('No se pudo cargar projects.json');
    const data = await res.json();
    const projects = (data.projects || []).sort((a, b) => (b.featured === true) - (a.featured === true));

    stat.textContent = projects.length;

    grid.innerHTML = projects.map(p => `
      <a class="project ${p.featured ? 'featured' : ''}" href="${escapeAttr(p.url)}" target="_blank" rel="noopener">
        <div class="project__head">
          <h3 class="project__name">
            ${escapeHtml(p.name)}
            ${p.featured ? '<span class="project__star" title="Destacado">★</span>' : ''}
          </h3>
          <span class="project__icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 17L17 7M9 7h8v8"/></svg>
          </span>
        </div>
        <p class="project__desc">${escapeHtml(p.description || '')}</p>
        <div class="project__meta">
          <span class="project__lang">${escapeHtml(p.language || '—')}</span>
          <div class="project__tags">
            ${(p.tags || []).map(t => `<span class="project__tag">${escapeHtml(t)}</span>`).join('')}
          </div>
        </div>
      </a>
    `).join('');
  } catch (err) {
    console.error(err);
    grid.innerHTML = `<p style="color:var(--muted)">No se pudieron cargar los proyectos. Revisa <code>projects.json</code>.</p>`;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  }
  function escapeAttr(s) { return escapeHtml(s); }
})();
